#pragma once

enum class DataType
{
  TEXT,
  NUMBER,
  CURRENCY,
  EGN,
  FACULTY_NUMBER
};
